step 3 :
Add  following columns in clinicians_education
other degree, other training

Step5:

Add table surgery

columns:
surgery_id
surgeryname
